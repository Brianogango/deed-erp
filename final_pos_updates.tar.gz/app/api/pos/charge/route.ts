import { NextResponse } from 'next/server'
import prisma from '@/lib/prisma'
import { getRequiredSession } from '@/lib/auth/api'

export async function POST(request: Request) {
  try {
    await getRequiredSession()
    const body = await request.json()
    const { lines, payment, customerId, customerName, pointsRedeemed, total, subtotal, taxTotal, ref } = body

    // Use Prisma transaction for atomicity
    const result = await prisma.$transaction(async (tx) => {
      // 1. Create the POS Transaction record
      const posTx = await tx.posTransaction.create({
        data: {
          ref: ref || `POS-${Date.now()}`,
          paymentMethod: payment,
          subtotal,
          taxTotal,
          total,
          clientId: customerId || null,
          pointsRedeemed: pointsRedeemed || 0,
          // Add other fields as per schema
        }
      })

      // 2. Create Invoice
      const invoice = await tx.invoice.create({
        data: {
          ref: `INV-POS-${posTx.id.slice(0, 8)}`,
          type: 'customer_invoice',
          status: 'paid',
          clientId: customerId || null,
          invoiceDate: new Date(),
          dueDate: new Date(),
          subtotal,
          taxTotal,
          total,
          amountPaid: total,
          items: {
            create: lines.map((l: any) => ({
              description: l.productName,
              qty: l.qty,
              unitPrice: l.price,
              lineSubtotal: l.subtotal,
              lineTotal: l.subtotal,
              productId: l.productId,
            }))
          }
        }
      })

      // 3. Update Stock & Create Stock Movements
      for (const line of lines) {
        // Decrement stock
        await tx.product.update({
          where: { id: line.productId },
          data: { stockQty: { decrement: line.qty } }
        })

        // Create movement
        await tx.stockMovement.create({
          data: {
            productId: line.productId,
            type: 'sale',
            quantity: line.qty,
            reference: invoice.ref,
            date: new Date(),
            // Add location info if tracked
          }
        })

        // Handle serial numbers if provided
        if (line.serialId) {
          await tx.serialNumber.update({
            where: { id: line.serialId },
            data: { status: 'sold', location: 'customer' }
          })
        }
      }

      // 4. Update Customer Loyalty Points
      if (customerId) {
        const pointsEarned = Math.floor(total / 100)
        await tx.client.update({
          where: { id: customerId },
          data: { 
            loyaltyPoints: { 
              increment: pointsEarned - (pointsRedeemed || 0) 
            } 
          }
        })
      }

      return { posTx, invoice }
    })

    return NextResponse.json({ ok: true, data: result })
  } catch (error: any) {
    console.error('POS Charge Error:', error)
    return NextResponse.json({ ok: false, error: error.message }, { status: 500 })
  }
}
