'use client'
import { useState, useRef, useEffect, useMemo } from 'react'
import { useApp, fmtKes, fmtDate } from '@/lib/store'
import { Modal, Field, Input, Badge, StatCard, ModuleSkeleton } from '@/components/ui'
import Fuse from 'fuse.js'
import { useHotkeys } from 'react-hotkeys-hook'

function ReceiptPrintView({ order, companySettings, onDone, mode = 'thermal' }: { order: any, companySettings: any, onDone: () => void, mode?: 'thermal' | 'a4' }) {
  useEffect(() => {
    const handleAfterPrint = () => {
      onDone()
      window.removeEventListener('afterprint', handleAfterPrint)
    }
    window.addEventListener('afterprint', handleAfterPrint)
    const timer = setTimeout(() => window.print(), 300)
    return () => {
      clearTimeout(timer)
      window.removeEventListener('afterprint', handleAfterPrint)
    }
  }, [onDone])

  if (mode === 'a4') {
    return (
      <div className="print-receipt-container bg-white text-black p-8" style={{ width: '210mm', minHeight: '297mm', margin: '0 auto' }}>
        <div className="flex justify-between border-b-2 border-gray-800 pb-4 mb-8">
          <div>
            {companySettings.logoUrl ? (
              <img src={companySettings.logoUrl} style={{ maxHeight: 80, objectFit: 'contain' }} alt="Logo" />
            ) : (
              <h1 className="font-bold text-3xl">{companySettings.name}</h1>
            )}
            <p className="mt-2 text-sm">{companySettings.address}, {companySettings.city}</p>
            <p className="text-sm">Tel: {companySettings.phone}</p>
            {companySettings.kraPin && <p className="text-sm">PIN: {companySettings.kraPin}</p>}
          </div>
          <div className="text-right">
            <h2 className="text-4xl font-bold text-gray-400 uppercase">Tax Invoice</h2>
            <p className="mt-4">Invoice No: <strong>{order.ref}</strong></p>
            <p>Date: {fmtDate(order.date)}</p>
            <p>Payment: <span className="uppercase font-bold">{order.payment}</span></p>
          </div>
        </div>

        <div className="mb-8">
          <h3 className="text-gray-500 uppercase text-xs font-bold mb-2">Bill To:</h3>
          <p className="font-bold text-lg">{order.customerName || 'Walk-in Customer'}</p>
        </div>

        <table className="w-full mb-8">
          <thead>
            <tr className="bg-gray-100 text-left">
              <th className="p-2 border">Item Description</th>
              <th className="p-2 border text-center">Qty</th>
              <th className="p-2 border text-right">Unit Price</th>
              <th className="p-2 border text-right">Total</th>
            </tr>
          </thead>
          <tbody>
            {order.lines.map((l: any, i: number) => (
              <tr key={i}>
                <td className="p-2 border">{l.productName} {l.serialNumber && <span className="text-[10px] block text-gray-500">S/N: {l.serialNumber}</span>}</td>
                <td className="p-2 border text-center">{l.qty}</td>
                <td className="p-2 border text-right">{fmtKes(l.price)}</td>
                <td className="p-2 border text-right font-semibold">{fmtKes(l.subtotal)}</td>
              </tr>
            ))}
          </tbody>
        </table>

        <div className="flex justify-end">
          <div className="w-64">
            <div className="flex justify-between py-1 border-b"><span>Subtotal</span><span>{fmtKes(order.subtotal)}</span></div>
            <div className="flex justify-between py-1 border-b"><span>VAT (16%)</span><span>{fmtKes(order.taxTotal)}</span></div>
            {order.pointsRedeemed ? (<div className="flex justify-between py-1 border-b text-red-600"><span>Points Redeemed</span><span>-{fmtKes(order.pointsRedeemed)}</span></div>) : null}
            <div className="flex justify-between py-2 font-bold text-xl border-t-2 border-gray-800 mt-2">
              <span>TOTAL</span><span>{fmtKes(order.total)}</span>
            </div>
          </div>
        </div>

        <div className="mt-20 pt-8 border-t text-center text-gray-500 text-sm">
          <p>{companySettings.invoiceFooter || 'Thank you for your business!'}</p>
        </div>

        <style>{`
          @media print { 
            body * { visibility: hidden; } 
            .print-receipt-container, .print-receipt-container * { visibility: visible; } 
            .print-receipt-container { position: absolute; left: 0; top: 0; width: 100%; margin: 0; padding: 10mm; } 
            .no-print-area { display: none !important; }
          }
        `}</style>
      </div>
    )
  }

  return (
    <div className="print-receipt-container bg-white text-black" style={{ fontFamily: 'monospace', fontSize: '12px', width: '300px', margin: '0 auto', padding: '16px' }}>
      <div className="text-center pb-4 mb-4" style={{ borderBottom: '1px dashed #ccc' }}>
        {companySettings.logoUrl ? (
          <img src={companySettings.logoUrl} style={{ maxHeight: 60, margin: '0 auto 8px', objectFit: 'contain' }} alt="Logo" />
        ) : (
          <h2 className="font-bold text-lg mb-1">{companySettings.name}</h2>
        )}
        {companySettings.logoUrl && <h2 className="font-bold text-sm mb-1">{companySettings.name}</h2>}
        <p>{companySettings.address}, {companySettings.city}</p>
        <p>Tel: {companySettings.phone}</p>
        {companySettings.kraPin && <p>PIN: {companySettings.kraPin}</p>}
      </div>

      <div className="flex justify-between mb-4">
        <div>
          <p>Receipt: <strong>{order.ref}</strong></p>
          <p>Cashier: {order.createdByName || 'System'}</p>
          {order.customerName && <p>Customer: {order.customerName}</p>}
        </div>
        <div className="text-right">
          <p>Date: {fmtDate(order.date)}</p>
          <p>Time: {order.createdAt ? new Date(order.createdAt).toLocaleTimeString('en-KE', {hour: '2-digit', minute: '2-digit'}) : '--:--'}</p>
        </div>
      </div>

      <div className="flex flex-col gap-1.5 mb-4">
        <div className="flex justify-between font-bold pb-1 mb-1" style={{ borderBottom: '1px solid #eee' }}>
          <span>Item</span>
          <span>Total</span>
        </div>
        {order.lines.map((l: any, i: number) => (
          <div key={i} className="flex justify-between">
            <span>{l.productName} <br/><span className="text-[10px] text-gray-500">{l.qty} × {fmtKes(l.price)}</span></span>
            <span className="font-semibold">{fmtKes(l.subtotal)}</span>
          </div>
        ))}
      </div>

      <div className="pt-2 mb-4" style={{ borderTop: '1px dashed #ccc' }}>
        <div className="flex justify-between mb-1"><span>Subtotal + VAT</span><span>{fmtKes(order.subtotal + order.taxTotal)}</span></div>
        {order.pointsRedeemed ? (<div className="flex justify-between mb-1 text-red-600"><span>Points Redeemed</span><span>-{fmtKes(order.pointsRedeemed)}</span></div>) : null}
        <div className="flex justify-between font-bold text-sm pt-2 mt-2" style={{ borderTop: '1px solid #ccc' }}>
          <span>FINAL TOTAL</span><span>{fmtKes(order.total)}</span>
        </div>
        <div className="flex justify-between mt-2">
          <span>Payment Mode</span><span className="uppercase">{order.payment}</span>
        </div>
      </div>

      <div className="text-center pt-4" style={{ borderTop: '1px dashed #ccc' }}>
        {order.pointsEarned ? (
          <p className="font-semibold mb-2">⭐ +{order.pointsEarned} Loyalty Points Earned!</p>
        ) : null}
        <p>{companySettings.invoiceFooter || 'Thank you for your business!'}</p>
      </div>

      <div className="no-print-area text-center mt-6">
        <p className="text-xs text-gray-500">Printing receipt...</p>
        <button className="btn-outline mt-2" onClick={onDone}>Cancel / Done</button>
      </div>
      <style>{`
        @media print { 
          @page { margin: 0; }
          body * { visibility: hidden; } 
          .print-receipt-container, .print-receipt-container * { visibility: visible; } 
          .print-receipt-container { position: absolute; left: 0; top: 0; width: 80mm; margin: 0; padding: 2mm; font-family: 'Courier New', Courier, monospace; font-size: 11px; line-height: 1.2; color: #000; } 
          .no-print-area, .no-print-area * { display: none !important; } 
          /* Ensure text doesn't overflow 80mm */
          .flex { display: flex; }
          .justify-between { justify-content: space-between; }
          .text-center { text-align: center; }
        }
      `}</style>
    </div>
  )
}

export default function PointOfSale() {
  const [mounted, setMounted] = useState(false)
  useEffect(() => { setMounted(true) }, [])

  const { products, serials, contacts, createPOSOrder, posOrders, openPOSSession, closePOSSession, posSessionOpen, posSessionOpeningCash, showToast, companySettings, getCustomerCreditStatus } = useApp()

  const [cart, setCart] = useState<{ productId: string; productName: string; barcode: string; price: number; qty: number; image: string; serialId?: string; serialNumber?: string }[]>([])
  const [scanInput, setScanInput] = useState('')
  const [search, setSearch] = useState('')
  const [category, setCategory] = useState('All')
  const [payMethod, setPayMethod] = useState<'cash' | 'mpesa' | 'card'>('mpesa')
  const [currency, setCurrency] = useState<'KES' | 'USD'>('KES')
  const [exchangeRate, setExchangeRate] = useState(130) // 1 USD = 130 KES
  const [customerId, setCustomerId] = useState('')
  const [customerName, setCustomerName] = useState('')
  const [showOpenSession, setShowOpenSession] = useState(false)
  const [showCloseSession, setShowCloseSession] = useState(false)
  const [openingCash, setOpeningCash] = useState('50000')
  const [closingCash, setClosingCash] = useState('')
  const [receiptOrder, setReceiptOrder] = useState<typeof posOrders[0] | null>(null)
  const [cartOpen, setCartOpen] = useState(false)
  const [isPrinting, setIsPrinting] = useState(false)
  const [printMode, setPrintMode] = useState<'thermal' | 'a4'>('thermal')
  const [redeemPoints, setRedeemPoints] = useState<number | ''>('')
  const [applyVat, setApplyVat] = useState(true)
  const [showHistory, setShowHistory] = useState(false)
  const scanRef = useRef<HTMLInputElement>(null)
  const searchRef = useRef<HTMLInputElement>(null)

  // ── Parked Sales (Hold/Resume) ──────────────────────────────────────────────
  const [parkedSales, setParkedSales] = useState<{ id: string, cart: any[], customerId: string, customerName: string, date: string }[]>([])
  const parkCurrentSale = () => {
    if (cart.length === 0) return
    const id = Math.random().toString(36).substring(7)
    setParkedSales(prev => [...prev, { id, cart, customerId, customerName, date: new Date().toISOString() }])
    setCart([]); setCustomerId(''); setCustomerName(''); setRedeemPoints('')
    showToast('Sale parked successfully', 'success')
  }
  const resumeParkedSale = (id: string) => {
    const sale = parkedSales.find(s => s.id === id)
    if (!sale) return
    setCart(sale.cart)
    setCustomerId(sale.customerId)
    setCustomerName(sale.customerName)
    setParkedSales(prev => prev.filter(s => s.id !== id))
    showToast('Sale resumed', 'success')
  }

  // ── Fuzzy Search ────────────────────────────────────────────────────────────
  const sellable = useMemo(() => products.filter(p => p.canBeSold && p.isActive && p.stockQty > 0 || p.unit === 'service'), [products])
  const fuse = useMemo(() => new Fuse(sellable, {
    keys: ['name', 'barcode', 'category'],
    threshold: 0.3,
    distance: 100
  }), [sellable])

  const categories = ['All', ...Array.from(new Set(sellable.map(p => p.category)))]
  const customers = contacts.filter(c => c.isCustomer)

  const filteredProducts = useMemo(() => {
    let result = sellable
    if (category !== 'All') {
      result = result.filter(p => p.category === category)
    }
    if (search) {
      result = fuse.search(search).map(r => r.item)
    }
    return result.slice(0, 20) // Limit to 20 for performance
  }, [category, search, sellable, fuse])

  const cartSubtotal = cart.reduce((a, i) => a + i.price * i.qty, 0)
  const cartTax = applyVat && companySettings.vatRate > 0 ? Math.round(cartSubtotal * companySettings.vatRate / 100) : 0
  const cartTotalBeforePoints = cartSubtotal + cartTax
  const customerInfo = customers.find(c => c.id === customerId)
  const maxPoints = customerInfo ? Math.min(customerInfo.loyaltyPoints || 0, cartTotalBeforePoints) : 0
  const pointsToRedeem = Math.min(Number(redeemPoints) || 0, maxPoints)
  const cartTotal = cartTotalBeforePoints - pointsToRedeem
  const pointsToEarn = customerId ? Math.floor(cartTotal / 100) : 0

  const cartTotalInSelectedCurrency = currency === 'KES' ? cartTotal : cartTotal / exchangeRate
  const fmtCurrency = (val: number) => currency === 'KES' ? fmtKes(val) : `$ ${val.toFixed(2)}`
  
  const getShopQty = (productId: string, requiresSerial: boolean) => requiresSerial
    ? serials.filter(s => s.productId === productId && s.status === 'available' && s.location === 'shop').length
    : (products.find(p => p.id === productId)?.stockQty ?? 0)

  // ── Keyboard Shortcuts ──────────────────────────────────────────────────────
  useHotkeys('f2', (e) => { e.preventDefault(); charge() }, { enabled: posSessionOpen })
  useHotkeys('f4', (e) => { e.preventDefault(); searchRef.current?.focus() }, { enabled: posSessionOpen })
  useHotkeys('esc', (e) => { e.preventDefault(); setCart([]); setSearch(''); scanRef.current?.focus() }, { enabled: posSessionOpen })
  useHotkeys('f7', (e) => { e.preventDefault(); parkCurrentSale() }, { enabled: posSessionOpen && cart.length > 0 })

  // Barcode scanner — reads quickly typed characters (scanner emits chars fast then Enter)
  const handleScanKey = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      const code = scanInput.trim()
      if (!code) return
      const product = products.find(p => p.barcode === code)
      if (product) {
        if (product.unit !== 'service' && getShopQty(product.id, product.requiresSerial) <= 0) {
          showToast(`${product.name} is not available in shop stock`, 'error'); setScanInput(''); return
        }
        addToCart(product)
        showToast(`${product.name} added`, 'success')
      } else {
        showToast(`Barcode ${code} not found`, 'error')
      }
      setScanInput('')
      scanRef.current?.focus()
    }
  }

  // ── Optimistic Cart ─────────────────────────────────────────────────────────
  const addToCart = (product: typeof products[0]) => {
    // Optimistic check: immediately add to cart, if stock check fails later we notify
    if (product.requiresSerial) {
      const avail = serials.filter(s => s.productId === product.id && s.status === 'available' && s.location === 'shop')
      if (avail.length === 0) { showToast(`No shop units available for ${product.name}`, 'error'); return }
      const serial = avail[0]
      setCart(prev => {
        if (prev.find(i => i.serialId === serial.id)) { showToast('Unit already in cart', 'error'); return prev }
        return [...prev, { productId: product.id, productName: product.name, barcode: product.barcode, price: product.salePrice, qty: 1, image: product.image ?? '📦', serialId: serial.id, serialNumber: serial.serial }]
      })
    } else {
      setCart(prev => {
        const ex = prev.find(i => i.productId === product.id)
        if (ex) return prev.map(i => i.productId === product.id ? { ...i, qty: i.qty + 1 } : i)
        return [...prev, { productId: product.id, productName: product.name, barcode: product.barcode, price: product.salePrice, qty: 1, image: product.image ?? '📦' }]
      })
    }
  }

  const removeFromCart = (productId: string) => setCart(prev => prev.filter(i => i.productId !== productId))
  const setQty = (productId: string, qty: number) => {
    if (qty <= 0) { removeFromCart(productId); return }
    setCart(prev => prev.map(i => i.productId === productId ? { ...i, qty } : i))
  }

  const charge = () => {
    if (cart.length === 0) { showToast('Cart is empty', 'error'); return }
    if (!posSessionOpen) { showToast('No active POS session', 'error'); return }
    if (customerId) {
      const cs = getCustomerCreditStatus(customerId)
      if (cs.isLocked) { showToast(cs.message, 'error'); return }
    }
    // Final Stock Check
    for (const item of cart) {
      const p = products.find(x => x.id === item.productId)!
      if (p.unit !== 'service' && getShopQty(p.id, p.requiresSerial) < item.qty) {
        showToast(`Not enough shop stock for ${p.name}`, 'error'); return
      }
    }
    const lines = cart.map(i => ({ productId: i.productId, productName: i.productName, barcode: i.barcode, qty: i.qty, price: i.price, subtotal: i.price * i.qty, serialId: i.serialId, serialNumber: i.serialNumber }))
    
    // Server-side validation and atomic transaction
    const orderData = { 
      lines, 
      payment: payMethod, 
      customerId: customerId || undefined, 
      customerName: customerName || undefined, 
      pointsRedeemed: pointsToRedeem,
      total: cartTotal,
      subtotal: cartSubtotal,
      taxTotal: cartTax,
      ref: `POS/${Date.now().toString().slice(-6)}`
    }

    // Call atomic API
    fetch('/api/pos/charge', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(orderData)
    }).then(res => res.json()).then(res => {
      if (res.ok) {
        showToast('Transaction synced to server', 'success')
      } else {
        // If server fails, the local createPOSOrder still runs (Optimistic)
        // and Dexie will try to sync it later via the Service Worker
        console.error('Server sync failed:', res.error)
      }
    }).catch(err => console.error('Network error during sync:', err))

    createPOSOrder(lines, payMethod, customerId || undefined, customerName || undefined, pointsToRedeem)
    
    setReceiptOrder({ id: 'temp', ref: orderData.ref, sessionId: '', lines, subtotal: cartSubtotal, taxTotal: cartTax, total: cartTotal, payment: payMethod, date: new Date().toISOString().slice(0, 10), createdAt: new Date().toISOString(), pointsEarned: pointsToEarn, pointsRedeemed: pointsToRedeem })
    setCart([]); setCustomerId(''); setCustomerName(''); setRedeemPoints(''); setCartOpen(false)
    scanRef.current?.focus()
  }

  // Auto-focus scan input
  useEffect(() => { scanRef.current?.focus() }, [posSessionOpen])

  if (!posSessionOpen) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh]">
        <div className="text-5xl sm:text-6xl mb-4">🖥️</div>
        <h2 className="text-xl font-semibold mb-2 text-center px-4">Point of Sale</h2>
        <p className="text-sm text-t3 mb-6 text-center px-4">Open a session to issue stock from the shop location</p>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4 mb-8 w-full max-w-2xl px-4">
          <StatCard label="Today's Sales" value={fmtKes(posOrders.reduce((a, o) => a + o.total, 0))} color="#10B981" />
          <StatCard label="Transactions" value={posOrders.length} color="#8B5CF6" />
          <StatCard label="Session" value="Closed" color="#EF4444" />
        </div>

        {posOrders.length > 0 && (
          <div className="card overflow-hidden mb-6 w-full max-w-lg mx-4">
            <div className="px-4 py-3 border-b flex justify-between items-center" style={{ borderColor: 'var(--border-lt)' }}>
              <span className="text-xs font-semibold">Recent Orders</span>
              <button className="btn-secondary text-[10px] py-1" onClick={() => setShowHistory(true)}>View All</button>
            </div>
            {posOrders.slice(0, 5).map(o => (
              <div key={o.id} className="flex flex-col sm:flex-row sm:justify-between sm:items-center px-4 py-2.5 border-b text-xs gap-2" style={{ borderColor: 'var(--border-lt)' }}>
                <div>
                  <p className="font-mono font-medium">{o.ref}</p>
                  <p className="text-t3">{o.lines.length} item(s) · {o.payment.toUpperCase()}</p>
                </div>
                <span className="font-mono font-semibold sm:ml-auto" style={{ color: '#10B981' }}>{fmtKes(o.total)}</span>
              </div>
            ))}
          </div>
        )}

        <button className="btn-primary px-8 py-3 text-sm font-semibold w-full max-w-sm" onClick={() => setShowOpenSession(true)}>
          Open POS Session →
        </button>

        {showOpenSession && (
          <Modal title="Open Session" subtitle="Enter opening cash balance" width={380} onClose={() => setShowOpenSession(false)}>
            <Field label="Opening Cash (KES)"><Input value={openingCash} onChange={setOpeningCash} type="number" autoFocus /></Field>
            <div className="flex gap-2 justify-end">
              <button className="btn-outline" onClick={() => setShowOpenSession(false)}>Cancel</button>
              <button className="btn-primary" onClick={() => { openPOSSession(Number(openingCash) || 0); setShowOpenSession(false) }}>Open Session</button>
            </div>
          </Modal>
        )}
      </div>
    )
  }

  if (isPrinting && receiptOrder) {
    return <ReceiptPrintView order={receiptOrder} companySettings={companySettings} onDone={() => { setIsPrinting(false); setReceiptOrder(null) }} mode={printMode} />
  }

  if (!mounted) return <ModuleSkeleton />

  const cartItemCount = cart.reduce((a, i) => a + i.qty, 0)

  return (
    <div className="flex flex-col lg:flex-row gap-2 sm:gap-3 h-full min-h-0">
      {/* Left — Products */}
      <div className="flex flex-col gap-2 flex-1 min-w-0 overflow-hidden min-h-0">
        {/* Header with History & Parked Sales */}
        <div className="flex items-center justify-between pb-1">
           <h2 className="text-xs font-bold text-t1 uppercase tracking-wider">Retail Till</h2>
           <div className="flex gap-2">
             {parkedSales.length > 0 && (
               <button className="btn-secondary text-[10px] py-1 px-3 bg-amber-50 text-amber-700 border-amber-200" onClick={() => setShowHistory(true)}>
                 ⏸️ {parkedSales.length} Parked
               </button>
             )}
             <button className="btn-secondary text-[10px] py-1 px-3" onClick={() => setShowHistory(true)}>
               🧾 Transaction History
             </button>
           </div>
        </div>

        {/* Scanner bar */}
        <div className="flex gap-2 items-center p-3 rounded-xl" style={{ background: '#EEF2FF', border: '1px solid #C7D2FE' }}>
          <span className="text-xl flex-shrink-0">📷</span>
          <input ref={scanRef} className="form-input flex-1 font-mono" placeholder="Scan barcode or type here..." 
            value={scanInput} onChange={e => setScanInput(e.target.value)} onKeyDown={handleScanKey} />
          <span className="badge badge-green text-[10px]">Scanner Ready</span>
        </div>

        {/* Search + Category filter */}
        <div className="flex flex-col sm:flex-row gap-2">
          <input ref={searchRef} className="form-input flex-1 text-[11px] py-1.5" placeholder="Search product (F4)..."
            value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        <div className="flex gap-1 overflow-x-auto pb-1 scrollbar-hide">
          {categories.map(c => (
            <button key={c} onClick={() => setCategory(c)}
              className="px-3 py-1 rounded-full text-[10px] cursor-pointer flex-shrink-0 whitespace-nowrap transition-all"
              style={{
                background: category === c ? '#E8F3FA' : 'var(--bg-surface)',
                color: category === c ? '#1B2762' : 'var(--text-3)',
                border: `1px solid ${category === c ? '#A8D4E8' : 'var(--border-lt)'}`,
                fontWeight: category === c ? 600 : 400,
              }}>
              {c}
            </button>
          ))}
        </div>

        {/* Product grid */}
        <div className="flex-1 overflow-y-auto">
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-2 sm:gap-3 auto-rows-fr">
            {filteredProducts.map(p => {
              const inCart = cart.find(i => i.productId === p.id)
              return (
                <button key={p.id} onClick={() => addToCart(p)}
                  className="p-2 sm:p-3 rounded-xl text-left cursor-pointer transition-all flex flex-col gap-1.5 relative h-full"
                  style={{
                    background: inCart ? '#E8F3FA' : 'var(--bg-surface)',
                    border: inCart ? '1px solid #A8D4E8' : '1px solid var(--border-lt)',
                  }}>
                  {inCart && (
                    <div className="absolute top-1 right-1 w-3 h-3 rounded-full flex items-center justify-center text-[8px] font-bold text-white"
                      style={{ background: '#1B2762' }}>{inCart.qty}</div>
                  )}
                  <span className="text-xl sm:text-2xl">{p.image}</span>
                  <p className="text-[10px] sm:text-[11px] font-medium leading-tight line-clamp-2">{p.name}</p>
                  <p className="text-[9px] sm:text-[10px] font-mono font-semibold" style={{ color: '#10B981' }}>{fmtKes(p.salePrice)}</p>
                  <p className="text-[8px] sm:text-[9px]" style={{ color: p.stockQty <= p.minStock ? '#F59E0B' : 'var(--text-3)' }}>
                    {p.unit === 'service' ? 'Service' : `${getShopQty(p.id, p.requiresSerial)} in shop`}
                  </p>
                </button>
              )
            })}
            {filteredProducts.length === 0 && (
              <p className="col-span-full py-10 text-center text-xs text-t3">No products match</p>
            )}
          </div>
        </div>
      </div>

      {/* Mobile: floating cart toggle bar */}
      {cartItemCount > 0 && !cartOpen && (
        <button
          className="lg:hidden fixed bottom-4 left-4 right-4 z-40 flex items-center justify-between px-4 py-3 rounded-2xl shadow-2xl no-min min-h-[44px]"
          style={{ background: '#1B2762', color: '#fff', borderTop: '1px solid rgba(255,255,255,0.1)' }}
          onClick={() => setCartOpen(true)}
        >
          <span className="text-sm font-semibold flex-1 truncate">🛒 {cartItemCount} item{cartItemCount !== 1 ? 's' : ''}</span>
          <span className="text-sm font-bold font-mono ml-2">{fmtKes(cartTotal)}</span>
        </button>
      )}

      {/* Right — Cart */}
      <div className={[
        'flex flex-col rounded-xl overflow-hidden order-2 lg:order-none lg:flex lg:flex-shrink-0',
        'lg:w-80 xl:w-96 h-screen lg:h-auto',
        cartOpen ? 'fixed inset-0 z-50 rounded-none slide-up lg:relative lg:inset-auto lg:rounded-xl lg:pos-cart-sheet' : 'hidden lg:flex',
      ].join(' ')}
        style={{ background: 'var(--bg-card)', border: '1px solid var(--border-lt)' }}>
        <div className="flex items-center justify-between px-4 py-3 border-b flex-shrink-0" style={{ borderColor: 'var(--border-lt)' }}>
          <div className="flex items-center gap-2">
            <button className="lg:hidden no-min p-1 rounded-lg text-t3" style={{ background: 'var(--bg-surface)', border: '1px solid var(--border)', minHeight: 'unset' }}
              onClick={() => setCartOpen(false)}>← Back</button>
            <p className="text-xs font-semibold">Cart ({cartItemCount})</p>
          </div>
          <div className="flex gap-2 items-center">
            <button className="no-min text-[10px] font-semibold text-amber-600 hover:text-amber-700" onClick={parkCurrentSale}>⏸️ Park (F7)</button>
            {cart.length > 0 && <button className="no-min" style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#EF4444', fontSize: 10, minHeight: 'unset' }} onClick={() => setCart([])}>Clear</button>}
          </div>
        </div>

        {/* Customer */}
        <div className="px-3 py-2 border-b flex items-center justify-between" style={{ borderColor: 'var(--border-lt)' }}>
          <select className="form-select text-[11px] py-1.5 flex-1" value={customerId}
            onChange={e => { const c = customers.find(x => x.id === e.target.value); setCustomerId(e.target.value); setCustomerName(c?.name ?? ''); setRedeemPoints('') }}>
            <option value="">Walk-in Customer</option>
            {customers.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
          {customerId && (() => {
            const c = customers.find(x => x.id === customerId)
            return c?.loyaltyPoints ? (
              <span className="ml-2 text-[10px] font-semibold text-indigo-600 bg-indigo-50 px-2 py-1 rounded border border-indigo-100 whitespace-nowrap">
                ⭐ {c.loyaltyPoints} pts
              </span>
            ) : null
          })()}
        </div>

        {/* Cart items */}
        <div className="flex-1 overflow-y-auto p-2 sm:p-3">
          {cart.length === 0
            ? <div className="flex flex-col items-center justify-center h-full opacity-40 py-8">
                <p className="text-4xl sm:text-5xl mb-4">🛒</p>
                <p className="text-xs text-t3 text-center px-4">Scan or click products to add to cart</p>
                {parkedSales.length > 0 && (
                  <div className="mt-6 w-full px-4">
                    <p className="text-[10px] font-bold uppercase text-t2 mb-2">Parked Sales</p>
                    {parkedSales.map(s => (
                      <button key={s.id} className="w-full flex justify-between items-center p-2 mb-1 rounded bg-amber-50 border border-amber-100 text-[10px]" onClick={() => resumeParkedSale(s.id)}>
                        <span className="font-medium truncate">{s.customerName || 'Walk-in'}</span>
                        <span className="font-mono">{s.cart.length} items</span>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            : cart.map(item => (
              <div key={item.productId} className="flex items-center gap-2 p-2 sm:p-2.5 rounded-lg mb-1.5 hover:shadow-sm" style={{ background: '#F9FAFB', border: '1px solid var(--border-lt)' }}>
                <span className="text-lg sm:text-base flex-shrink-0">{item.image}</span>
                <div className="flex-1 min-w-0">
                  <p className="text-[11px] font-medium truncate">{item.productName}</p>
                  {item.serialNumber && <p className="text-[9px] font-mono" style={{ color: '#1B2762' }}>S/N: {item.serialNumber}</p>}
                  <p className="text-[10px] font-mono" style={{ color: '#10B981' }}>{fmtKes(item.price)}</p>
                </div>
                <div className="flex items-center gap-1 flex-shrink-0">
                  <button style={{ background: '#F3F4F6', border: '1px solid var(--border-lt)', cursor: 'pointer', color: 'var(--text-1)', width: 24, height: 24, borderRadius: 4, fontSize: 14, minWidth: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}
                    onClick={() => setQty(item.productId, item.qty - 1)}>-</button>
                  <span className="text-xs font-mono w-6 text-center font-bold">{item.qty}</span>
                  <button style={{ background: '#F3F4F6', border: '1px solid var(--border-lt)', cursor: 'pointer', color: 'var(--text-1)', width: 24, height: 24, borderRadius: 4, fontSize: 14, minWidth: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}
                    onClick={() => setQty(item.productId, item.qty + 1)}>+</button>
                </div>
                <div className="w-20 text-right flex-shrink-0">
                  <p className="text-[11px] font-mono font-semibold">{fmtKes(item.price * item.qty)}</p>
                  <button style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#F04438', fontSize: 10, fontWeight: 500, padding: 0 }}
                    onClick={() => removeFromCart(item.productId)}>Remove</button>
                </div>
              </div>
            ))
          }
        </div>

        {/* Totals */}
        <div className="border-t p-3 shrink-0" style={{ borderColor: 'var(--border-lt)' }}>
          <div className="flex justify-between text-xs mb-1"><span className="text-t3">Subtotal</span><span className="font-mono">{fmtKes(cartSubtotal)}</span></div>
          <div className="flex justify-between text-xs mb-2 items-center">
            <label className="flex items-center gap-2 cursor-pointer text-xs select-none">
              <input type="checkbox" checked={applyVat} onChange={e => setApplyVat(e.target.checked)} />
              <span className="text-t3">VAT ({companySettings.vatRate}%)</span>
            </label>
            <span className="font-mono text-t3">{fmtKes(cartTax)}</span>
          </div>
          {customerId && maxPoints > 0 && (
            <div className="flex justify-between text-xs mb-2 items-center">
              <span className="text-t3">Redeem Points (Max {maxPoints})</span>
              <input type="number" className="form-input text-xs text-right py-0.5 w-20 h-6" value={redeemPoints} onChange={e => setRedeemPoints(e.target.value === '' ? '' : Math.min(maxPoints, Math.max(0, Number(e.target.value))))} />
            </div>
          )}
          {customerId && pointsToEarn > 0 && (
            <div className="flex justify-between text-xs mb-2 font-semibold" style={{ color: '#4F46E5' }}>
              <span>Points to Earn</span><span className="font-mono">+{pointsToEarn} pts</span>
            </div>
          )}
          <div className="flex justify-between items-center mb-2">
            <span className="text-[10px] font-bold text-t3 uppercase">Currency</span>
            <div className="flex gap-1">
              <button className={`px-2 py-0.5 rounded text-[10px] font-bold ${currency === 'KES' ? 'bg-brand-blue text-white' : 'bg-gray-100'}`} onClick={() => setCurrency('KES')}>KES</button>
              <button className={`px-2 py-0.5 rounded text-[10px] font-bold ${currency === 'USD' ? 'bg-brand-blue text-white' : 'bg-gray-100'}`} onClick={() => setCurrency('USD')}>USD</button>
            </div>
          </div>
          {currency === 'USD' && (
            <div className="flex justify-between text-[10px] mb-2 text-t3">
              <span>Rate: 1 USD = {exchangeRate} KES</span>
              <button className="text-brand-blue" onClick={() => { const r = prompt('Enter USD Rate', exchangeRate.toString()); if(r) setExchangeRate(Number(r)) }}>Edit</button>
            </div>
          )}
          <div className="flex justify-between text-base font-bold mb-4 pt-1 border-t" style={{ borderColor: 'var(--border-lt)' }}>
            <span>Total</span><span className="font-mono text-lg" style={{ color: '#10B981' }}>{fmtCurrency(cartTotalInSelectedCurrency)}</span>
          </div>

          {/* Payment method */}
          <div className="grid grid-cols-3 sm:grid-cols-2 lg:grid-cols-3 gap-1.5 mb-4">
            {(['mpesa', 'cash', 'card'] as const).map(m => (
              <button key={m} onClick={() => setPayMethod(m)}
                className="py-2 sm:py-1.5 rounded-lg text-[10px] sm:text-sm font-semibold uppercase cursor-pointer transition-all min-h-[40px]"
                style={{
                  background: payMethod === m ? '#E8F3FA' : 'var(--bg-surface)',
                  color: payMethod === m ? '#1B2762' : 'var(--text-3)',
                  border: `1px solid ${payMethod === m ? '#A8D4E8' : 'var(--border-lt)'}`,
                  fontWeight: payMethod === m ? 600 : 400,
                }}>
                {m === 'mpesa' ? '📱 M-Pesa' : m === 'cash' ? '💵 Cash' : '💳 Card'}
              </button>
            ))}
          </div>

          <button className="btn-primary w-full py-3 text-sm font-semibold min-h-[48px]" onClick={charge}
            style={{ background: cart.length > 0 ? '#12B76A' : '#E5E7EB', color: cart.length > 0 ? '#fff' : 'var(--text-3)', cursor: cart.length > 0 ? 'pointer' : 'default' }}>
            {cart.length > 0 ? `Charge ${fmtCurrency(cartTotalInSelectedCurrency)} (F2)` : 'Add items to cart'}
          </button>
        </div>
      </div>

      {/* Receipt modal */}
      {receiptOrder && (
        <Modal title="Order Complete" subtitle="Transaction successful" width={480} onClose={() => setReceiptOrder(null)}>
          <div className="text-center py-4">
            <div className="text-5xl mb-4">✅</div>
            <p className="text-lg font-semibold mb-2">{receiptOrder.payment.toUpperCase()} Payment Received</p>
            <p className="text-3xl font-bold font-mono" style={{ color: '#10B981' }}>{fmtKes(receiptOrder.total)}</p>
            {receiptOrder.pointsEarned ? (<p className="text-sm font-semibold mt-2" style={{ color: '#4F46E5' }}>⭐ +{receiptOrder.pointsEarned} Loyalty Points Earned!</p>) : null}
          </div>
          
          <div className="mb-6 p-4 rounded-xl bg-gray-50 border border-gray-100">
            <p className="text-[10px] font-bold text-gray-400 uppercase mb-3">Receipt Format</p>
            <div className="flex gap-3">
              <button className={`flex-1 py-3 rounded-lg border-2 transition-all ${printMode === 'thermal' ? 'border-brand-blue bg-blue-50' : 'border-gray-200 bg-white'}`} onClick={() => setPrintMode('thermal')}>
                <p className="text-xl mb-1">🖨️</p>
                <p className="text-xs font-bold">Thermal (80mm)</p>
              </button>
              <button className={`flex-1 py-3 rounded-lg border-2 transition-all ${printMode === 'a4' ? 'border-brand-blue bg-blue-50' : 'border-gray-200 bg-white'}`} onClick={() => setPrintMode('a4')}>
                <p className="text-xl mb-1">📄</p>
                <p className="text-xs font-bold">Full A4 Invoice</p>
              </button>
            </div>
          </div>

          <div className="flex gap-2 justify-end flex-wrap">
            <button className="btn-outline min-h-[40px] flex-1 sm:flex-none" onClick={() => setIsPrinting(true)}>Print Receipt</button>
            <button className="btn-primary min-h-[40px] flex-1 sm:flex-none" onClick={() => { setReceiptOrder(null); scanRef.current?.focus() }}>New Order</button>
          </div>
        </Modal>
      )}

      {showCloseSession && (
        <Modal title="Close Session" width={480} onClose={() => setShowCloseSession(false)}>
          <Field label="Closing Cash Count (KES)"><Input value={closingCash} onChange={setClosingCash} type="number" autoFocus /></Field>
          <div className="p-3 rounded text-xs" style={{ background: 'var(--bg-surface)', border: '1px solid var(--border-lt)' }}>
            <p>Session orders: <strong>{posOrders.length}</strong></p>
            <p className="mt-1">Total revenue: <strong className="font-mono" style={{ color: '#10B981' }}>{fmtKes(posOrders.reduce((a, o) => a + o.total, 0))}</strong></p>
          </div>
          <div className="flex gap-2 justify-end">
            <button className="btn-outline" onClick={() => setShowCloseSession(false)}>Cancel</button>
            <button className="btn-primary" style={{ background: '#F04438' }} onClick={() => { closePOSSession(Number(closingCash)); setShowCloseSession(false) }}>Close Session</button>
          </div>
        </Modal>
      )}

      {/* History modal */}
      {showHistory && (
        <Modal title="POS Transactions History" onClose={() => setShowHistory(false)} width={740}>
           <div className="overflow-x-auto w-full">
             <div className="min-w-[650px] flex flex-col">
               <div className="table-head" style={{ gridTemplateColumns: '110px 1fr 110px 80px 100px 90px' }}>
                  <span>Receipt Ref</span><span>Customer</span><span>Date & Time</span><span>Payment</span><span>Total</span><span>Action</span>
               </div>
               <div className="max-h-96 overflow-y-auto">
                 {posOrders.map(o => (
                    <div key={o.id} className="table-row" style={{ gridTemplateColumns: '110px 1fr 110px 80px 100px 90px' }}>
                      <span className="font-mono text-[11px] font-bold text-brand-navy">{o.ref}</span>
                      <span className="text-xs truncate">{o.customerName || 'Walk-in'}</span>
                      <span className="text-[10px] text-t3">{fmtDate(o.date)} {o.createdAt ? new Date(o.createdAt).toLocaleTimeString('en-KE', {hour: '2-digit', minute:'2-digit'}) : ''}</span>
                      <span className="text-[10px] uppercase font-semibold">{o.payment}</span>
                      <span className="font-mono text-[11px] font-bold text-emerald-600">{fmtKes(o.total)}</span>
                      <button className="btn-secondary text-[10px] py-1" onClick={() => { setReceiptOrder(o); setIsPrinting(true); setShowHistory(false); }}>🖨️ Reprint</button>
                    </div>
                 ))}
                 {posOrders.length === 0 && <p className="py-10 text-center text-xs text-t3">No transactions found</p>}
               </div>
             </div>
           </div>
        </Modal>
      )}
    </div>
  )
}
