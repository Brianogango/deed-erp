'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import { useRouter, usePathname } from 'next/navigation'

import { AppProvider, useApp, User } from '@/lib/store'
import SwRegister from './SwRegister'
import { Toast } from '@/components/ui'
import Sidebar from '@/components/layout/Sidebar'
import Topbar from '@/components/layout/Topbar'

// ═══════════════════════════════════════════════════════════════════════════
// CONSTANTS
// ═══════════════════════════════════════════════════════════════════════════

// Auto-logout after 30 minutes of inactivity
const INACTIVITY_TIMEOUT_MS = 30 * 60 * 1000
// Warn 2 minutes before auto-logout
const WARN_BEFORE_MS = 2 * 60 * 1000
// Grace period before logging out on network loss (5 seconds)
const OFFLINE_GRACE_MS = 5 * 1000

// ═══════════════════════════════════════════════════════════════════════════
// COMPONENTS
// ═══════════════════════════════════════════════════════════════════════════

/**
 * Offline Banner Component
 * Displays when network connection is lost
 */
function OfflineBanner({ gracePeriodSeconds }: { gracePeriodSeconds: number }) {
  return (
    <div className="
      fixed top-0 inset-x-0 z-[100]
      flex items-center justify-center gap-2
      bg-red-600 px-4 py-2 text-white text-xs font-semibold shadow-lg
    ">
      <span>⚠ No internet connection — POS is now in Offline Mode (Sales will sync later)</span>
    </div>
  )
}

/**
 * Inactivity Warning Modal Component
 * Warns user before auto-logout due to inactivity
 */
function InactivityWarningModal({ onContinue }: { onContinue: () => void }) {
  return (
    <div className="fixed inset-0 z-[99] flex items-center justify-center bg-black/60 backdrop-blur-sm">
      <div className="
        bg-[var(--bg-card)] rounded-2xl shadow-2xl p-6 mx-4 max-w-sm w-full
        text-center transition-all duration-200
      ">
        <div className="
          w-12 h-12 rounded-full bg-amber-100 flex items-center justify-center
          mx-auto mb-4
        ">
          <span className="text-2xl">⏱</span>
        </div>
        <h3 className="text-base font-bold text-[var(--text-1)] mb-1">Still there?</h3>
        <p className="text-xs text-[var(--text-3)] mb-5">
          You&apos;ve been inactive for a while. You will be signed out in 2 minutes unless you
          continue.
        </p>
        <button
          className="
            w-full py-2.5 rounded-lg
            bg-primary-500 hover:bg-primary-600
            text-white text-sm font-semibold
            transition-colors duration-200
          "
          onClick={onContinue}
        >
          Continue Session
        </button>
      </div>
    </div>
  )
}

/**
 * Sidebar Overlay Backdrop Component
 * Closes sidebar when clicked on mobile
 */
function SidebarBackdrop({ onClose }: { onClose: () => void }) {
  return (
    <div
      className="fixed inset-0 z-40 bg-black/50 md:hidden transition-opacity duration-200"
      onClick={onClose}
    />
  )
}

/**
 * Main App Content Component
 * Manages layout, session, and auth state
 */
function AppContent({ children }: { children: React.ReactNode }) {
  const [mounted, setMounted] = useState(false)
  useEffect(() => setMounted(true), [])

  const router = useRouter()
  const pathname = usePathname()
  const { currentUserId, currentUser, toast, sidebarOpen, toggleSidebar, logout } = useApp()

  const inactivityTimer = useRef<ReturnType<typeof setTimeout> | null>(null)
  const warnTimer = useRef<ReturnType<typeof setTimeout> | null>(null)
  const offlineTimer = useRef<ReturnType<typeof setTimeout> | null>(null)
  const contentRef = useRef<HTMLElement>(null)
  const [showInactivityWarning, setShowInactivityWarning] = useState(false)
  const [offlineBanner, setOfflineBanner] = useState(false)

  // Lock body scroll when mobile sidebar drawer is open
  useEffect(() => {
    document.body.style.overflow = sidebarOpen ? 'hidden' : ''
    return () => { document.body.style.overflow = '' }
  }, [sidebarOpen])

  // Smooth scroll-to-top on route change
  useEffect(() => {
    if (contentRef.current) {
      contentRef.current.scrollTo({ top: 0, behavior: 'smooth' })
    }
  }, [pathname])

  /**
   * Handle logout with reason tracking
   */
  const doLogout = useCallback(
    async (reason: 'inactivity' | 'network') => {
      setShowInactivityWarning(false)
      await logout()
      router.replace(`/login?reason=${reason}`)
    },
    [logout, router]
  )

  /**
   * Reset inactivity timer on user activity
   */
  const resetInactivityTimer = useCallback(() => {
    if (!currentUserId) return
    setShowInactivityWarning(false)
    if (inactivityTimer.current) clearTimeout(inactivityTimer.current)
    if (warnTimer.current) clearTimeout(warnTimer.current)

    warnTimer.current = setTimeout(() => {
      setShowInactivityWarning(true)
    }, INACTIVITY_TIMEOUT_MS - WARN_BEFORE_MS)

    inactivityTimer.current = setTimeout(() => {
      void doLogout('inactivity')
    }, INACTIVITY_TIMEOUT_MS)
  }, [currentUserId, doLogout])

  /**
   * Inactivity auto-logout effect
   */
  useEffect(() => {
    if (!currentUserId) return
    const events = ['mousemove', 'mousedown', 'keydown', 'touchstart', 'scroll', 'click']
    events.forEach(e => window.addEventListener(e, resetInactivityTimer, { passive: true }))
    resetInactivityTimer()
    return () => {
      events.forEach(e => window.removeEventListener(e, resetInactivityTimer))
      if (inactivityTimer.current) clearTimeout(inactivityTimer.current)
      if (warnTimer.current) clearTimeout(warnTimer.current)
    }
  }, [currentUserId, resetInactivityTimer])

  /**
   * Network loss auto-logout effect
   */
  useEffect(() => {
    if (!currentUserId) return

    const handleOffline = () => {
      setOfflineBanner(true)
      // Disable auto-logout for offline POS capability
      // offlineTimer.current = setTimeout(() => {
      //   void doLogout('network')
      // }, OFFLINE_GRACE_MS)
    }

    const handleOnline = () => {
      setOfflineBanner(false)
      if (offlineTimer.current) clearTimeout(offlineTimer.current)
    }

    window.addEventListener('offline', handleOffline)
    window.addEventListener('online', handleOnline)
    return () => {
      window.removeEventListener('offline', handleOffline)
      window.removeEventListener('online', handleOnline)
      if (offlineTimer.current) clearTimeout(offlineTimer.current)
    }
  }, [currentUserId, doLogout])

  /**
   * Auth state and route guard effect
   */
  useEffect(() => {
    if (!currentUserId) {
      router.replace('/login')
    }
  }, [currentUserId, currentUser, router, pathname])

  // Hydration guard
  if (!mounted) {
    return <div className="h-screen w-full bg-[var(--bg-page)]" />
  }

  // Not authenticated
  if (!currentUserId) {
    return (
      <div className="
        flex min-h-screen items-center justify-center
        bg-[var(--bg-page)] px-6 text-sm text-[var(--text-3)]
      ">
        Your session has ended. Redirecting to sign in.
      </div>
    )
  }

  return (
    <div className="flex h-screen w-full overflow-hidden bg-[var(--bg-page)]">
      {/* Network Offline Banner */}
      {offlineBanner && <OfflineBanner gracePeriodSeconds={OFFLINE_GRACE_MS / 1000} />}

      {/* Inactivity Warning Modal */}
      {showInactivityWarning && <InactivityWarningModal onContinue={resetInactivityTimer} />}

      {/* Sidebar Overlay Backdrop */}
      {sidebarOpen && <SidebarBackdrop onClose={toggleSidebar} />}

      {/* Sidebar */}
      <Sidebar />

      {/* Main Content Area */}
      <div className="flex min-w-0 flex-1 flex-col overflow-hidden">
        {/* Topbar */}
        <Topbar />

        {/* Main Content */}
        <main
          ref={contentRef}
          className="
            flex-1 overflow-y-auto overflow-x-hidden
            p-3 md:p-4 lg:p-5 xl:p-6
            transition-all duration-200
          "
          style={{ overscrollBehavior: 'contain', WebkitOverflowScrolling: 'touch' } as React.CSSProperties}
        >
          <div key={pathname} className="view-enter">
            {children}
          </div>
        </main>
      </div>

      {/* Toast Notifications */}
      <Toast toast={toast} />
    </div>
  )
}

/**
 * AppShell Wrapper Component
 * Provides app context and initializes state
 */
export default function AppShell({
  initialUser,
  initialUsers,
  serverState,
  children,
}: {
  initialUser: User
  initialUsers: User[]
  serverState?: Record<string, unknown> | any
  children: React.ReactNode
}) {
  return (
    <AppProvider initialUser={initialUser} initialUsers={initialUsers} serverState={serverState}>
      <SwRegister />
      <AppContent>{children}</AppContent>
    </AppProvider>
  )
}
